const Header = () => {
    return <header>
        <p>header</p>
    </header>;
}

export default Header;