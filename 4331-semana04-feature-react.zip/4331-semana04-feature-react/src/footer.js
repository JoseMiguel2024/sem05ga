const Footer = () => {
    return <footer>
        <p>footer</p>
    </footer>;
}

export default Footer;