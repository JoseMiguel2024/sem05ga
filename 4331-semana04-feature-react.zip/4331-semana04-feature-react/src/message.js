const Message = ({ message }) => {
    return <h1>Message: {message}</h1>;
}

export default Message;