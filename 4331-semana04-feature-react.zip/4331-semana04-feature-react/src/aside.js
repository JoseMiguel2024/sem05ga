const Aside = () => {
    return <aside>
        <p>aside</p>
    </aside>;
}

export default Aside;